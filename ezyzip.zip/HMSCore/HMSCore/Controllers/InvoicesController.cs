﻿using HMSCore.Models.Invoices;
using HMSCore.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HMSCore.Controllers
{
    [Authorize]
    public class InvoicesController : Controller
    {
        private readonly IInvoicesService invoiceService;

        public InvoicesController(IInvoicesService iService)
        {
            this.invoiceService = iService;
        }

        public IActionResult All([FromQuery] AllInvoicesQueryModel query)
        {

            var allInvoices = invoiceService.All(query);

            return this.View(allInvoices);
        }

        public IActionResult Details(string id)
        {
            var currentInvoice = this.invoiceService.Details(id);

            return this.View(currentInvoice);
        }

        public IActionResult Delete(string id)
        {
            this.invoiceService.Delete(id);

            return this.RedirectToAction("All", "Invoices");
        }

        public IActionResult Pay(string id)
        {
            this.invoiceService.Pay(id);

            return this.RedirectToAction("All", "Invoices");
        }

    }
}
