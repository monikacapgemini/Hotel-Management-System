﻿namespace HMSCore.Areas.Admin.Models.Countries
{
    public class CountriesViewModel
    {
        public string Id { get; set; }

        public string Name { get; set; }
    }
}