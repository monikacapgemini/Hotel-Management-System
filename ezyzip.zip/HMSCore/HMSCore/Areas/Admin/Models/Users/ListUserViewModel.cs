﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HMSCore.Areas.Admin.Models.Users
{
    public class ListUserViewModel
    {
        public string Email { get; set; }

        public string Role { get; set; }

        public string Id { get; set; }
    }
}