﻿namespace HMSCore.Areas.Admin.Models.Cities
{
    public class CitiesViewModel
    {
        public string Name { get; set; }

        public string Country { get; set; }

        public string Id { get; set; }
    }
}