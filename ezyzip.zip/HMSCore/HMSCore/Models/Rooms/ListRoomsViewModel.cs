﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HMSCore.Models.Rooms
{
    public class ListRoomsViewModel
    {
        public string Id { get; set; }

        public string RoomNumber { get; set; }

        public string RoomType { get; set; }
    }
}