﻿namespace HMSCore.Models.GuestRanks
{
    public class AllRanksViewModel
    {
        public string Id { get; set; }

        public string Name { get; set; }

        public int Discount { get; set; }
    }
}