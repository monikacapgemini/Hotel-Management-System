﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HMSCore.Models.Reservations
{
    public class RoomViewModel
    {
        public string Id { get; set; }

        public string Name { get; set; }

        public string Type { get; set; }
    }
}