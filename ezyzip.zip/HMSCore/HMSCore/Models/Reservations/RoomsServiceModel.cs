﻿namespace HMSCore.Models.Reservations
{
    public class RoomsServiceModel
    {
        public string Id { get; set; }

        public string Number { get; set; }

        public decimal Price { get; set; }
    }
}