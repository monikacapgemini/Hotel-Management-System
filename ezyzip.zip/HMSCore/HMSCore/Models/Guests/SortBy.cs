﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HMSCore.Models.Guests
{
    public enum SortBy
    {
        None = 0,
        FName = 1,
        LName = 2,
        City = 3,
        CreatedOn = 4,
        Phone = 5,
        Rank = 6
    }
}