﻿using HMSCore.Models.AboutUs;

namespace HMSCore.Services
{
    public interface IAboutUs
    {
        AboutUsViewModel AboutUsData();
    }
}