﻿namespace DataLayer.Models.Enums
{
    public enum ReservationStatus
    {
        Confirmed = 0,
        Pending = 1,
        Canceled = 2
    }
}
