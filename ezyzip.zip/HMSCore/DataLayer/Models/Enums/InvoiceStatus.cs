﻿namespace DataLayer.Models.Enums
{
    public enum InvoiceStatus
    {
        Active = 0,
        Pending = 1,
        Canceled = 2
    }
}